package com.TourWebMagic;

import java.util.List;

import com.jayway.jsonpath.JsonPathException;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.pipeline.FilePipeline;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.selector.JsonPathSelector;


public class MakeTourdate implements PageProcessor{
	private Site site = Site.me().setUserAgent(
			"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/604.4.7 (KHTML, like Gecko) Version/11.0.2 Safari/604.4.7\"")
			.setRetryTimes(10)
			.setSleepTime(5000)
			.setTimeOut(10000)
			;
	public void process(Page page) {
		
		List url = page.getHtml().xpath("*div[@class='post-cover']/a/@href").all();
		//System.out.println(url);
		page.addTargetRequests(url);
		//游记内部数据
		List title = page.getHtml().xpath("//div[@class='vi_con']/h1/text()").all();
		List mdd = page.getHtml().xpath("//a[@class='_j_mdd_stas']/@title").all();
		List time = page.getHtml().xpath("//li[@class='time']/text()").all();
		List days = page.getHtml().xpath("//li[@class='day']/text()").all();
		List cost = page.getHtml().xpath("//li[@class='cost']/text()").all();
		List data = page.getHtml().xpath("//p[@class='_j_note_content _j_seqitem']/text()").all();
//				System.out.println(title);
//		
//		System.out.println(mdd);
//		System.out.println(time+","+days+","+cost);
//*****list 改 string
		//System.out.println(data);
//		String datas = String.join("", data);
		//System.out.println("AAAAAAAAAAAAAAAAAAAAAAA"+datas);
		
		page.putField("title", title);
		page.putField("mdd", mdd);
		page.putField("time", time);
		page.putField("days", days);
		page.putField("cost", cost);
		page.putField("datas", data);
		
		//下一页
			//page.addTargetRequest("https://www.mafengwo.cn/i/10767922.html");
		for (int i = 77; i <= 80; i++) {
			page.addTargetRequest("http://www.mafengwo.cn/yj/21536/1-0-"+i+".html");
		}
		//System.out.println(page.getUrl());
	}
	public Site getSite() {
		// TODO Auto-generated method stub
		return site;
	}
	

	public static void main(String[] args) {
		Spider.create(new MakeTourdate())			
				.addUrl("https://www.mafengwo.cn/yj/21536/1-0-76.html")
				//.addPipeline(new FilePipeline("E://MaFengWoyj.txt"))
				.addPipeline(new MakeTourMySQLPipeline())
				.thread(5)
				.run();
	}
}