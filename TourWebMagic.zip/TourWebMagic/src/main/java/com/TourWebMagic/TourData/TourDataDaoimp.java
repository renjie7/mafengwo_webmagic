package com.TourWebMagic.TourData;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.TourWebMagic.entity.TourData;

public class TourDataDaoimp implements TourDataDao{

	public void addTourdata(TourData tourdata) {
		// TODO Auto-generated method stub
		Connection con =null;
		PreparedStatement pre = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			con= DriverManager.getConnection("jdbc:mysql://localhost:3306/tourdata?useUnicode=true&characterEncoding=UTF-8", "root", "root");
			//SQL语句
			String sql = "insert into tourdatas(tour_title,tour_mmd,tour_time,tour_days,tour_cost,tour_data) values (?,?,?,?,?,?);";
			pre = con.prepareStatement(sql);
			pre.setString(1, tourdata.getTitle());
			pre.setString(2, tourdata.getTour_mmd());
			pre.setString(3, tourdata.getTour_time());
			pre.setString(4, tourdata.getTour_days());
			pre.setString(5, tourdata.getTour_cost());
		    pre.setString(6, tourdata.getTour_data());
			
			
			pre.execute();
			System.out.println("加入数据库成功");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				pre.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

}
