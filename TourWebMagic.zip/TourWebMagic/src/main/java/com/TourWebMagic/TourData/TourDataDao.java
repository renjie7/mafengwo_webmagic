package com.TourWebMagic.TourData;

import com.TourWebMagic.entity.TourData;

public interface TourDataDao {
	public void addTourdata(TourData tourdata);
}
