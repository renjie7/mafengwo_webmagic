package com.TourWebMagic.entity;

public class TourData {
	
	private int id;
	private String title;
	private String Tour_mmd;
	private String Tour_time;
	private String Tour_days;
	private String Tour_cost;
	private String Tour_data;
	
	public TourData() {
		// TODO Auto-generated constructor stub
	}
	
	public TourData(int id, String title, String tour_time, String tour_days, String tour_cost, String tour_data) {
		super();
		this.id = id;
		this.title = title;
		Tour_time = tour_time;
		Tour_days = tour_days;
		Tour_cost = tour_cost;
		Tour_data = tour_data;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTour_mmd() {
		return Tour_mmd;
	}
	public  void setTour_mmd(String tour_mmd) {
		Tour_mmd = tour_mmd;
	}
	public String getTour_time() {
		return Tour_time;
	}
	public void setTour_time(String tour_time) {
		Tour_time = tour_time;
	}
	public String getTour_days() {
		return Tour_days;
	}
	public void setTour_days(String tour_days) {
		Tour_days = tour_days;
	}
	public String getTour_cost() {
		return Tour_cost;
	}
	public void setTour_cost(String tour_cost) {
		Tour_cost = tour_cost;
	}
	public String getTour_data() {
		return Tour_data;
	}
	public void setTour_data(String tour_data) {
		Tour_data = tour_data;
	}

	@Override
	public String toString() {
		return "TourData [id=" + id + ", title=" + title + "]";
	}
	
	
}
