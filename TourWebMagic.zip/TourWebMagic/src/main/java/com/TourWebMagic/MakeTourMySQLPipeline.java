package com.TourWebMagic;

import java.io.File;
import java.util.List;

import com.TourWebMagic.TourData.TourDataDao;
import com.TourWebMagic.TourData.TourDataDaoimp;
import com.TourWebMagic.entity.TourData;

import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.Pipeline;

public class MakeTourMySQLPipeline implements Pipeline {

	public void process(ResultItems resultItems, Task task) {
		// TODO Auto-generated method stub
		TourData tourdata= new TourData();
		
		 List title = resultItems.get("title");
		 List<String> Tour_mdd = resultItems.get("mdd");
		 List<String> Tour_time = resultItems.get("time");
		 List<String> Tour_days = resultItems.get("days");
		 List<String> Tour_cost = resultItems.get("cost");
		 List<String> Tour_data = resultItems.get("datas");
		 
		 //存入TXT
			System.out.println(title);
			System.out.println(Tour_mdd);
			System.out.println(Tour_time+","+Tour_days+","+Tour_cost);
			System.out.println(Tour_data);
		//插入数据库
		for (int i = 0; i <title.size() ; i++) {
			tourdata.setTitle((String) title.get(i));
			tourdata.setTour_cost((String) Tour_cost.get(i));
			tourdata.setTour_mmd((String)Tour_mdd.get(i));
			tourdata.setTour_time(Tour_time.get(i));
			tourdata.setTour_days(Tour_days.get(i));
			tourdata.setTour_data(Tour_data.get(i));
			
			
			TourDataDao Tourdatadao = new TourDataDaoimp();
			Tourdatadao.addTourdata(tourdata);
		}
			
	}
	
}
